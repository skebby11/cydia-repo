

// Windows 10 Wallpaper for Xen HTML - Made by skebby (Sebastiano Riva) - www.sebastianoriva.it


// Your name
var name = "My name";


// Display mail
var displaymail = true;


// Your mail
var mail = "mail@example.com";


// Display icon
var displayicon = true;


// Dark or white icon
var darkicon = true;


// Dark or white text
var darktext = false;


// Clock ON/OFF true/false
var clock = true;


// Date ON/OFF true/false
var date = true;


// Day ON/OFF true/false
var day = true;


// Default Win 10 Background
var win10bg = true;
