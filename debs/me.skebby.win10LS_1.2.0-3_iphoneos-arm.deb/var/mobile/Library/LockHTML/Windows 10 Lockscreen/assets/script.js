//
// Weekday and month script for 
// Windows 10 Lockscreen
// by skebby (Sebastiano Riva)
// www.sebastianoriva.it
//

document.getElementById("name").innerHTML = name;
document.getElementById("mail").innerHTML = mail;


// Toggle win10 or default background
if(win10bg == true) {
document.getElementById("Page2").style = "background: url('assets/bg.png') no-repeat center center / cover;";
}

// Toggle icon to dark
if(darkicon == false) {
document.getElementById("userLogo").style = "background: url('user_white.png'); width: 300px; background-size: cover;";
} 

// Toggle text to dark
if(darktext == true) {
document.getElementsByClassName("hour").style = "color: #000";
$('.hour').css('color', '#000');
$('h1').css('color', '#000');
$('h3').css('color', '#000');
} 
  
// Toggle email
if(displaymail == true) {
 $('.userEmail').show();} 
	else {
 $('.userEmail').hide(); }
  
// Toggle user icon
if(displayicon == true) {
 $('#userLogo').show();} 
	else {
 $('#userLogo').hide(); }

// Toggle time
if(clock == true) {
 $('#time').show();} 
	else {
 $('#time').hide(); }

// Toggle week day
if(day == true) {
 $('#day').show();}   
	else {
 $('#day').hide();} 

// Toggle date
if(date == true) {
 $('#date').show();} 
	else {
 $('#date').hide();} 




