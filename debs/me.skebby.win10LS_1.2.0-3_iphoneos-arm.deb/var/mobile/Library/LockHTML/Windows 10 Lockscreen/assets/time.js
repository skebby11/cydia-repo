//
// Weekday and month script for 
// Windows 10 Lockscreen
// by skebby (Sebastiano Riva)
// www.sebastianoriva.it
//

    var d = new Date();
    var weekday = new Array(7);
    weekday[0] = "Sunday";
    weekday[1] = "Monday";
    weekday[2] = "Tuesday";
    weekday[3] = "Wednesday";
    weekday[4] = "Thursday";
    weekday[5] = "Friday";
    weekday[6] = "Saturday";

    var getday = weekday[d.getDay()];
    document.getElementById("day").innerHTML = getday;


    var d = new Date();
    var months = new Array(12);
    months[0] = "January";
    months[1] = "February";
    months[2] = "March";
    months[3] = "April";
    months[4] = "May";
    months[5] = "June";
    months[6] = "July";
    months[7] = "August";
    months[8] = "September";
    months[9] = "October";
    months[10] = "November";
    months[11] = "December";

    var getmonth = months[d.getMonth()];
	var getdate = d.getDate();
    document.getElementById("date").innerHTML = getmonth +" "+ getdate;

function addZero(i) {
	if (i < 10) { 
		i = "0" + i;
	} return i;
} 

var d = new Date(); 
var h = addZero(d.getHours()); 
var m = addZero(d.getMinutes()); 
document.getElementById("time").innerHTML = h+":"+m;
