

// Windows 10 Wallpaper for Xen HTML - Made by skebby (Sebastiano Riva) - www.sebastianoriva.it


// Your name
var name = "Sebastiano Riva";


// Your mail
var mail = "mail@example.com";


// Image ON/OFF true/false
var icon = true;


// Your img file name
var imgpath = "user_black.png";


// Clock ON/OFF true/false
var clock = true;


// Date ON/OFF true/false
var date = true;


// Day ON/OFF true/false
var day = true;


// Default Win 10 Background
var win10bg = true;
