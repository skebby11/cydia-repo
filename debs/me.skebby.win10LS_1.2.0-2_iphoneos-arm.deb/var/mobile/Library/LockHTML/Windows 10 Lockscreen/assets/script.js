//
// Weekday and month script for 
// Windows 10 Lockscreen
// by skebby (Sebastiano Riva)
// www.sebastianoriva.it
//

document.getElementById("name").innerHTML = name;
document.getElementById("mail").innerHTML = mail;


if(icon == true) {
document.getElementsByClassName("userLogo").style = "visibility: visible"; } 
if(icon == false) {
document.getElementsByClassName("userLogo").style = "visibility: hidden"; }


document.getElementsByClassName("userLogo").style = "background-image: url(" + imgpath + ");";

if(clock == true) {
document.getElementById("time").style = "visibility: visible"; } 
	else {
document.getElementById("time").style = "visibility: hidden"; }

if(day == true) {
document.getElementById("day").style = "visibility: visible"; } 
	else {
document.getElementById("day").style = "visibility: hidden"; }

if(date == true) {
document.getElementById("date").style = "visibility: visible"; } 
	else {
document.getElementById("date").style = "visibility: hidden"; }


if(win10bg == true) {
document.getElementById("Page2").style = "background: url('assets/bg.png') no-repeat center center / cover;";
}